Copyright (c) 2014 Ray Sun
