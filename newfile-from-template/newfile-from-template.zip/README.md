newfile-from-template
=====================
###it's an Extension of Brackets,you can new a file from your template,you can edit the template.it's so easy!

How to use:
----------
it in your menu "new as" when your install complete and you can use hotkey too.<b>if you want edit the template don't change the filename!

templates:
---------
- html-template.html
- js-template.js
-  css-template.css
- php-template.php

Hotkey:
-------
- New html -- ctrl+shift+h;
- New js -- ctrl+shift+j;
- New css -- ctrl+shift+c;
- New php -- ctrl+shift+p;

Version 1.1.0
-------------
Update:Create a new file by your selected file as same path.the new file's name is your selected file's name.new.html(js or css or php).