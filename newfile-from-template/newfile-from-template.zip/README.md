Newfile from template
=====================
#it's an Extension of Brackets,you can new a file from your template,you can edit the template.it's so easy!

templates:
---------
- html-template.html
- js-template.js
-  css-template.css
- php-template.php

Hotkey:
-------
- New html -- ctrl+shift+h;
- New js -- ctrl+shift+j;
- New css -- ctrl+shift+c;
- New php -- ctrl+shift+p;